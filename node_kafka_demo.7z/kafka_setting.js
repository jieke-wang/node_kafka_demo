const kafkaSetting = {
    clientId: "my-app",
    brokers: ['192.168.199.133:9092']
};

module.exports = kafkaSetting;